import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-hot-toast"; // Import toast
import UserProfileModel from "./UserProfileModel";
import Navbar from "./components/Navbar";
import { toast } from "react-hot-toast"; // Import toast

function Events() {
  const [events, setEvents] = useState([]);
  const [showUserProfileModal, setShowUserProfileModal] = useState(false);
  const [user, setUser] = useState();

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchEvents();
  }, []);

  const openUserProfileModal = () => {
    const userData = JSON.parse(localStorage.getItem("user"));
    setUser(userData);
    setShowUserProfileModal(true);
  };

  const closeUserProfileModal = () => {
    setShowUserProfileModal(false);
  };

  function formatDate(dateString) {
    const options = { year: "numeric", month: "long", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  }

  const fetchEvents = async () => {
    try {
      const response = await fetch("https://ticket-a8ez.onrender.com/event/all", {
        headers: {
          Authorization: `${token}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        const data = await response.json();
        setEvents(data);
      } else {
        console.error("Failed to fetch events.");
        toast.error("Failed to fetch events.");
      }
    } catch (error) {
      console.error("Error during fetchEvents:", error);
      toast.error("An error occurred while fetching events.");
    }
  };

  const handleBookEvent = async (eventId) => {
    try {
      const response = await fetch(`https://ticket-a8ez.onrender.com/ticket/user`, {
        headers: {
          Authorization: `${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        console.error("Failed to fetch user tickets.");
        toast.error("Failed to fetch user tickets.");
        return;
      }

      const data = await response.json();
      const userTickets = data.userTickets;

      const isAlreadyBooked = userTickets.some((ticket) => ticket.event._id === eventId);

      if (isAlreadyBooked) {
        toast.error("Event is already booked!");
      } else {
        const bookResponse = await fetch(`https://ticket-a8ez.onrender.com/ticket`, {
          method: "POST",
          headers: {
            Authorization: `${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ eventId }),
        });

        if (bookResponse.ok) {
          toast.success("Event booked successfully!");
        } else {
          console.error("Failed to book event.");
          toast.error("Failed to book event.");
        }
      }
    } catch (error) {
      console.error("Error during event booking:", error);
      toast.error("An error occurred while booking the event.");
    }
  };

  return (
    <div className="events">
      {/* Navbar */}
      <Navbar />

      <Link to="/create">
        <button className="events-button">Create Events</button>
      </Link>

      {/* Event cards */}
      <div className="event-cards">
        {events.map((event) => (
          <div key={event.id} className="event-card">
            <h2>{event.title}</h2>
            <p>{event.description}</p>
            <p>Date: {formatDate(event.date)}</p>
            <p>Venue: {event.venue}</p>
            <p>Price: ${event.price}</p>
            <button className="button" onClick={() => handleBookEvent(event._id)}>
              Book
            </button>
          </div>
        ))}
      </div>

      {showUserProfileModal && (
        <UserProfileModel user={user} onClose={closeUserProfileModal} />
      )}
    </div>
  );
}

export default Events;
