import React, { useEffect, useState } from "react";
import { Link, useNavigate } from 'react-router-dom';
import UserProfileModel from "../UserProfileModel";

function Navbar() {
  const navigate = useNavigate();
  const [showUserProfileModal, setShowUserProfileModal] = useState(false);
  const [userData, setUserData] = useState({});
  const [user, setUser] = useState();
  const token = localStorage.getItem("token");

  const openUserProfileModal = () => {
    const userData = JSON.parse(localStorage.getItem("user"));
    setUser(userData);
    setShowUserProfileModal(true);
  };

  const closeUserProfileModal = () => {
    setShowUserProfileModal(false);
  };
  const fetchUserData = async (token) => {
    try {
      const response = await fetch("https://ticket-a8ez.onrender.com/user", {
        headers: {
          "Content-Type": "application/json",
          Authorization: `${token}`,
        },
      });
      if (response.ok) {
        const data = await response.json();
        console.log(data);
        setUserData(data);
      } else {
        console.error("Error fetching user data");
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };
  
    useEffect(() => {
      if (token) {
        fetchUserData(token);

      
      }
    }, [token]);
  const handleLogout = () => {
    // Remove user-related data from localStorage
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    localStorage.removeItem('email');

    // Redirect to login page or another page
    navigate('/login');
};
  return (
 <>
    {/* Navbar */}
    <nav className="navbar">
        {/* Left side */}
        <div className="left">
          <Link to={"/dashboard"}><img src="https://img.icons8.com/?size=100&id=JLPLEG0POCbJ&format=png&color=000000" alt="App" /></Link>
          <span>Event Booking App</span>
        </div>
        {/* Right side */}
        <div className="right">
          <Link to={"/dashboard"}><button className="events-button">Home</button></Link>
          <Link to={"/events"}><button className="events-button">Events</button></Link>
          <button className="profile-button" onClick={openUserProfileModal}>My Profile</button>
          <button className="events-button" onClick={handleLogout}>
            Logout
        </button>
        </div>
      </nav>
      {showUserProfileModal && (
        <UserProfileModel
          user={user}
          onClose={closeUserProfileModal}
        />
      )}
 </>
  )
}

export default Navbar
